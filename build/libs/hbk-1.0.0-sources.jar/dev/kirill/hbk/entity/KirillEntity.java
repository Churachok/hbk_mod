package dev.kirill.hbk.entity;

import dev.kirill.hbk.registry.ModItems;
import dev.kirill.hbk.item.AttackingMemberItem;
import dev.kirill.hbk.item.MemberWeaponItem;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** A peaceful wanderer who only fights entities that attack him first. */
public final class KirillEntity extends PathfinderMob implements RangedAttackMob {
	public KirillEntity(EntityType<? extends KirillEntity> type, Level level) {
		super(type, level);
		this.setPersistenceRequired();
		this.xpReward = 5;
	}

	public static AttributeSupplier.Builder createAttributes() {
		return PathfinderMob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 20.0)
				.add(Attributes.MOVEMENT_SPEED, 0.30)
				.add(Attributes.FOLLOW_RANGE, 24.0)
				.add(Attributes.ATTACK_DAMAGE, 6.0);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new RangedAttackGoal(this, 1.0, 12, 16.0f));
		this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 1.0));
		this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 10.0f));
		this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		boolean hurt = super.hurtServer(level, source, amount);
		if (hurt && source.getEntity() instanceof LivingEntity attacker && attacker != this) {
			this.armForRetaliation();
			this.setTarget(attacker);
		}
		return hurt;
	}

	private void armForRetaliation() {
		if (!this.getMainHandItem().is(ModItems.ATTACKING_MEMBER)) {
			this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.ATTACKING_MEMBER));
			// The independently rolled entity loot table is the only way the weapon drops.
			this.setDropChance(EquipmentSlot.MAINHAND, 0.0f);
		}
	}

	@Override
	protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
		// Enforce this at death too: existing NPCs may have old saved equipment chances.
		if (this.getMainHandItem().is(ModItems.ATTACKING_MEMBER)) {
			this.setDropChance(EquipmentSlot.MAINHAND, 0.0f);
		}
		super.dropCustomDeathLoot(level, source, recentlyHit);
	}

	@Override
	public void performRangedAttack(LivingEntity target, float pullProgress) {
		if (!(this.level() instanceof ServerLevel level)) {
			return;
		}

		AttackingMemberBulletEntity bullet = new AttackingMemberBulletEntity(
				level,
				this,
				AttackingMemberItem.BULLET_DAMAGE
		);
		double dx = target.getX() - this.getX();
		double dy = target.getY(0.5) - bullet.getY();
		double dz = target.getZ() - this.getZ();
		double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
		bullet.shoot(dx, dy + horizontalDistance * 0.08, dz, MemberWeaponItem.BULLET_SPEED, 0.15f);
		level.addFreshEntity(bullet);
		level.playSound(null, this.getX(), this.getEyeY(), this.getZ(),
				SoundEvents.SNOWBALL_THROW, SoundSource.NEUTRAL, 0.8f,
				0.75f + this.getRandom().nextFloat() * 0.15f);
		this.swing(InteractionHand.MAIN_HAND, true);
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.VILLAGER_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.PLAYER_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.PLAYER_DEATH;
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}
}
